
const int redLED = 12;
const int greenLED = 14;

void setup() {
  pinMode(redLED, OUTPUT);
  pinMode(greenLED, OUTPUT);

  Serial.begin(115200);
  Serial.println("ESP32 CPS LED SYSTEM STARTED");
}

void loop() {

  // Red ON, Green OFF
  digitalWrite(redLED, HIGH);
  digitalWrite(greenLED, LOW);

  Serial.println("RED LED ON | GREEN LED OFF");
  delay(1000);

  // Red OFF, Green ON
  digitalWrite(redLED, LOW);
  digitalWrite(greenLED, HIGH);

  Serial.println("RED LED OFF | GREEN LED ON");
  delay(1000);
}
