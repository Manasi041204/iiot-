#include <DHT.h>

#define DHTPIN 2
#define DHTTYPE DHT22

DHT dht(DHTPIN, DHTTYPE);

float temperature = 25.0;
float humidity = 50.0;

void setup() {
  Serial.begin(9600);
  dht.begin();

  Serial.println("IoT Temperature and Humidity Monitoring");
  Serial.println("----------------------------------------");
}

void loop() {

  // Simulate automatic environmental changes
  temperature += random(-10, 11) / 10.0;
  humidity += random(-20, 21) / 10.0;

  // Keep values within realistic limits
  temperature = constrain(temperature, 20, 35);
  humidity = constrain(humidity, 35, 80);

  Serial.print("Temperature: ");
  Serial.print(temperature);
  Serial.print(" °C");

  Serial.print("  |  Humidity: ");
  Serial.print(humidity);
  Serial.println(" %");

  delay(2000);
}