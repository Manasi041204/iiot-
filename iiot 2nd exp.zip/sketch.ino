
int pirPin = 2;
int ledPin = 13;

int motionState = LOW;
int previousState = LOW;

void setup() {
  pinMode(pirPin, INPUT);
  pinMode(ledPin, OUTPUT);

  Serial.begin(9600);

  Serial.println("PIR MOTION DETECTION SYSTEM");
  Serial.println("System Started Successfully");
}

void loop() {

  motionState = digitalRead(pirPin);

  if (motionState == HIGH) {

    digitalWrite(ledPin, HIGH);

    if (previousState == LOW) {
      Serial.println("Motion Detected!");
      Serial.println("LED ON");
    }

  } 
  else {

    digitalWrite(ledPin, LOW);

    if (previousState == HIGH) {
      Serial.println("No Motion Detected!");
      Serial.println("LED OFF");
    }
  }

  previousState = motionState;

  delay(100);
}
