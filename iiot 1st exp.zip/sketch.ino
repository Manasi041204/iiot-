
const int potPin = 34;
int potValue = 0;

void setup() {
  Serial.begin(115200);
  analogReadResolution(12);

  Serial.println("================================");
  Serial.println(" ESP32 ALERT SYSTEM STARTED");
  Serial.println("================================");
}

void loop() {
  potValue = analogRead(potPin);

  Serial.print("Potentiometer Value: ");
  Serial.println(potValue);

  if (potValue > 2000) {
    Serial.println("WARNING! HIGH VALUE DETECTED!");
    Serial.println("Alert Status: DANGER");
  } else {
    Serial.println("Alert Status: NORMAL");
  }

  Serial.println("--------------------------------");
  delay(500);
}
