const int potPin = 34;

void setup() {
  Serial.begin(115200);
  analogReadResolution(12);
  pinMode(potPin, INPUT);
}

void loop() {
  int potValue = analogRead(potPin);

  Serial.print("Potentiometer Value: ");
  Serial.println(potValue);

  delay(500);
}